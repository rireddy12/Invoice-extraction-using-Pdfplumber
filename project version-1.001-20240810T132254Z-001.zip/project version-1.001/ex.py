import pandas as pd
from sqlalchemy import create_engine

# Define your MySQL connection details
mysql_user = 'haritha'
mysql_password = 'spsoft'
mysql_host = '192.168.5.46'
mysql_database = 'test_del'

# Establish a connection using SQLAlchemy
engine = create_engine(f'mysql+mysqlconnector://{mysql_user}:{mysql_password}@{mysql_host}/{mysql_database}')
print(engine)

# Read the CSV file into a DataFrame
csv_file_path = 'output_table_2.csv'  # Update this with your CSV file path
df = pd.read_csv(csv_file_path)

# Save the DataFrame to the MySQL database
table_name = 'Release_details'
df.to_sql(name=table_name, con=engine, if_exists='replace', index=True)

print(f'DataFrame from {csv_file_path} saved to MySQL table {table_name} successfully.')
